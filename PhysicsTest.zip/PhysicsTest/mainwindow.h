#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <Box2D/Box2D.h>
#include <SFML/Graphics.hpp>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    void mousePressEvent(QMouseEvent* event);
    void CreateGround(b2World& world, float x, float y);
    void CreateBox(b2World& world, int mouseX, int mouseY);
public slots:
    void updateGame();
};

#endif // MAINWINDOW_H
