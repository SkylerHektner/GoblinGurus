#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMouseEvent>
#include <QDebug>
#include <QVector>
#include <QTimer>
#include <QWidget>

int scale = 30;
b2Vec2 gravity(0.f, 9.8f);
b2World world(gravity);
sf::Texture BoxTexture;
sf::Texture GroundTexture;
QVector<QWidget*> listOfWidgets;
bool newBox = false;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->background->setStyleSheet("background-image: url(\"/Users/Trevor/Documents/cs3505/PhysicsTest/Assets/level_template.jpg\"); background-position: center;");
    BoxTexture.loadFromFile("/Users/Trevor/Documents/cs3505/PhysicsTest/Assets/ground.png");
    if(BoxTexture.loadFromFile("/Users/Trevor/Documents/cs3505/PhysicsTest/Assets/goblin_base.png")){
        qDebug() << "YAAAAAA!";
    }
    else
        qDebug() << "DERP!";
    CreateGround(world, 100.0f, 500.0f);
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateGame()));
    timer->start(17);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mousePressEvent(QMouseEvent *event){
    CreateBox(world, event->x(), event->y());
    newBox = true;
    QWidget* boxWidget = new QWidget(this);
    boxWidget->setGeometry(event->x(), event->y(), 40, 40);
    boxWidget->setStyleSheet("background-color:black;");
    listOfWidgets.append(boxWidget);
    //boxWidget->show();
}

void MainWindow::updateGame(){

    world.Step(1/58.0f, 8, 3);
    int BodyCount = 0;
    for (b2Body* BodyIterator = world.GetBodyList(); BodyIterator != 0; BodyIterator = BodyIterator->GetNext())
    {
        if (BodyIterator->GetType() == b2_dynamicBody)
        {
            qDebug() << scale * BodyIterator->GetPosition().x << scale * BodyIterator->GetPosition().y;
            listOfWidgets[BodyCount]->show();
            //lets just do some black boxes
            listOfWidgets[BodyCount]->setGeometry(scale * BodyIterator->GetPosition().x, scale * BodyIterator->GetPosition().y, 40, 40);

            //boxWidget->setStyleSheet("background-color:black;");
            //For sprite background transform
//            sf::Sprite Sprite;
//            Sprite.setTexture(BoxTexture);
//            Sprite.setOrigin(16.0f, 16.0f);
//            Sprite.setPosition(scale * BodyIterator->GetPosition().x, scale * BodyIterator->GetPosition().y);
//            Sprite.setRotation(BodyIterator->GetAngle() * 180/b2_pi);
            ++BodyCount;
        }
        else
        {
            QWidget* boxWidget = new QWidget(this);
            boxWidget->setGeometry(0, scale * BodyIterator->GetPosition().y, 800, 8);
            boxWidget->setStyleSheet("background-color:green;");

            boxWidget->show();
//            sf::Sprite GroundSprite;
//            GroundSprite.setTexture(GroundTexture);
//            GroundSprite.setOrigin(400.f, 8.f);
//            GroundSprite.setPosition(BodyIterator->GetPosition().x * scale, BodyIterator->GetPosition().y * scale);
//            GroundSprite.setRotation(180/b2_pi * BodyIterator->GetAngle());
        }
    }
}

void MainWindow::CreateGround(b2World &world, float x, float y){
    b2BodyDef BodyDef;
    BodyDef.position = b2Vec2(x/scale, y/scale);
    BodyDef.type = b2_staticBody;
    b2Body* Body = world.CreateBody(&BodyDef);
    b2PolygonShape Shape;
    Shape.SetAsBox((800.0f)/scale, (16.0f)/scale); // Creates a box shape. Divide your desired width and height by 2.
    b2FixtureDef FixtureDef;
    FixtureDef.density = 0.f;  // Sets the density of the body
    FixtureDef.shape = &Shape; // Sets the shape
    Body->CreateFixture(&FixtureDef); // Apply the fixture definition
}

void MainWindow::CreateBox(b2World &world, int mouseX, int mouseY){
    b2BodyDef BodyDef;
    BodyDef.position = b2Vec2(mouseX/scale, mouseY/scale);
    BodyDef.type = b2_dynamicBody;
    b2Body* Body = world.CreateBody(&BodyDef);

    b2PolygonShape Shape;
    Shape.SetAsBox((40.f/2)/scale, (40.f/2)/scale);
    b2FixtureDef FixtureDef;
    FixtureDef.density = 1.f;
    FixtureDef.friction = 0.7f;
    FixtureDef.shape = &Shape;
    Body->CreateFixture(&FixtureDef);
}

